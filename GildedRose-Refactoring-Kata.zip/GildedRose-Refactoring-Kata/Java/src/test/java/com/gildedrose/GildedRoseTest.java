package com.gildedrose;

import com.gildedrose.items.Item;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GildedRoseTest {
    @Test
    void foo() {
        GildedRose app = newGildedRose("foo", 0, 0);
        app.updateQuality();
        assertEquals("foo", app.items[0].name);
    }

    @Test
    public void decrementSellForItemByDay() {
        GildedRose app = newGildedRose("standard item", 10, 10);
        app.updateQuality();
        assertEquals(9, itemSellIn(app));
    }

    @Test
    public void decrementSellForBrieByDay() {
        GildedRose app = newGildedRose(ItemFactory.BRIE, 0, 0);
        app.updateQuality();
        assertEquals(-1, itemSellIn(app));
    }

    @Test
    public void incrementQualityForBrie() {
        GildedRose app = newGildedRose(ItemFactory.BRIE, 1, 4);
        app.updateQuality();
        assertEquals(5, itemQuality(app));
    }

    @Test
    public void incrementQualityForBackstageWithMore12ItemSellIn() {
        GildedRose app = newGildedRose(ItemFactory.BACKSTAGE, 12, 3);
        app.updateQuality();
        assertEquals(4, itemQuality(app));
    }

    @Test
    public void increment2QualityForBackstageWithBetween7And10ItemSellIn() {
        GildedRose app = newGildedRose(ItemFactory.BACKSTAGE, 10, 2);
        app.updateQuality();
        assertEquals(4, itemQuality(app));
    }

    @Test
    public void increment3QualityForBackstageWithLess6ItemSellIn() {
        GildedRose app = newGildedRose(ItemFactory.BACKSTAGE, 5, 4);
        app.updateQuality();
        assertEquals(7, itemQuality(app));
    }
    @Test
    public void qualityForBackstage0WhenItemSellIn0() {
        GildedRose app = newGildedRose(ItemFactory.BACKSTAGE, 0,50);
        app.updateQuality();
        assertEquals(0, itemQuality(app));
    }

    @Test
    public void qualityForBackstageMax50() {
        GildedRose app = newGildedRose(ItemFactory.BACKSTAGE, 5, 50);
        app.updateQuality();
        assertEquals(50, itemQuality(app));
    }

    @Test
    public void decrement1ForNormalItem() {
        GildedRose app = newGildedRose("normal", 2, 2);
        app.updateQuality();
        assertEquals(1, itemQuality(app));
    }

    @Test
    public void decrement2ForNormalItemWithSellInPassed() {
        GildedRose app = newGildedRose("normal",0, 7);
        app.updateQuality();
        assertEquals(5, itemQuality(app));
    }

    @Test
    public void NotQualityBelowZeroForNormalItem() {
        GildedRose app = newGildedRose("normal", 0, 0);
        app.updateQuality();
        assertEquals(0, itemQuality(app));
    }

    @Test
    public void noChangesQualityAndSellInForSulfura() {
        GildedRose app = newGildedRose(ItemFactory.SULFURAS, 1, 80);
        app.updateQuality();
        assertEquals(80, itemQuality(app));
        assertEquals(1, itemSellIn(app));
    }

    @Test
    public void decrement2ForConjured() {
        GildedRose app = newGildedRose(ItemFactory.CONJURED, 2, 8);
        app.updateQuality();
        assertEquals(6, itemQuality(app));
    }


    private GildedRose newGildedRose(String itemName, int itemSellIn, int itemQuality) {
        Item[] items = new Item[] { new Item(itemName, itemSellIn, itemQuality)};
        return new GildedRose(items);
    }


    private int itemSellIn(GildedRose gildedRose) {
        return gildedRose.items[0].sellIn;
    }

    private int itemQuality(GildedRose app) {
        return app.items[0].quality;
    }
}
