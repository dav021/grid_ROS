package com.gildedrose.items;


public class NormalItem implements ItemPersonalized {

    private final Item item;

    public NormalItem(Item item) {
        this.item = item;
    }

    public void update() {
        item.sellIn -= 1;
        if (item.sellIn > 0) {
            decrementQualityBy(1);
        } else {
            decrementQualityBy(2);
        }
    }

    private void decrementQualityBy(int quality) {
        item.quality -= quality;
    }
}
