package com.gildedrose.items;

public class SulfurasItem implements ItemPersonalized {
    @Override
    public void update() {}
}
