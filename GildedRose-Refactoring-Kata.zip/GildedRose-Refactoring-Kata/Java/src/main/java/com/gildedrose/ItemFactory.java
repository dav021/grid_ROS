package com.gildedrose;

import com.gildedrose.items.*;

import java.util.HashMap;
import java.util.Map;

public class ItemFactory {

    private final static Map<String, ItemPersonalized> ITEM_LIST = new HashMap<>();
    public final static String SULFURAS = "Sulfuras";
    public final static String BRIE = "Aged Brie";
    public final static String BACKSTAGE = "Backstage passes";
    public final static String CONJURED = "Conjured";

    public ItemFactory(Item item) {
        ITEM_LIST.put(SULFURAS, new SulfurasItem());
        ITEM_LIST.put(BRIE, new AgedBrieItem(item));
        ITEM_LIST.put(BACKSTAGE, new BackstageItem(item));
        ITEM_LIST.put(CONJURED, new ConjuredItem(item));
    }

    public ItemPersonalized customiseItem(Item item) {
        return !ITEM_LIST.containsKey(item.name) ? new NormalItem(item) : ITEM_LIST.get(item.name);
    }

}
