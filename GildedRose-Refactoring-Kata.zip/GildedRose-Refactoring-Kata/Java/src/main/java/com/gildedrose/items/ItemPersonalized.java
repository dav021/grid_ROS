package com.gildedrose.items;

public interface ItemPersonalized {
    void update();
}

