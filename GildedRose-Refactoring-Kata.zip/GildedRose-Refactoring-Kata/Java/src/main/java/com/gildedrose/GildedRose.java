package com.gildedrose;

import com.gildedrose.items.Item;
import com.gildedrose.items.ItemPersonalized;

import java.util.Arrays;

class GildedRose {
    private static final int ZERO = 0;
    Item[] items;

    public GildedRose(Item[] items) {
        this.items = items;
    }

    public void updateQuality() {
        Arrays.stream(this.items).forEach(item -> {
            itemPersonalized(item).update();
            if (item.quality < ZERO) {
                item.quality = ZERO;
            } else if (item.quality > maxQuality(item)) {
                item.quality = maxQuality(item);
            }
        });
    }

    private ItemPersonalized itemPersonalized(Item item) {
        return new ItemFactory(item).customiseItem(item);
    }
    private int maxQuality(Item item) {
        return item.name.equals(ItemFactory.SULFURAS) ? 80 : 50;
    }
}
