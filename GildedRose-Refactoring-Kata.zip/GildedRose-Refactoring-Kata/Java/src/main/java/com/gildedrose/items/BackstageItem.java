package com.gildedrose.items;


public class BackstageItem implements ItemPersonalized {

    private final Item item;

    public BackstageItem(Item item) {
        this.item = item;
    }

    public void update() {
        item.sellIn -= 1;
        if (item.sellIn >10) {
            decrementQualityBy(1);
        } else if (item.sellIn >5) {
            decrementQualityBy(2);
        } else if (item.sellIn > 0) {
            decrementQualityBy(3);
        } else {
            item.quality = 0;
        }
    }

    private void decrementQualityBy(int qualityValue) {
        item.quality += qualityValue;
    }
}
