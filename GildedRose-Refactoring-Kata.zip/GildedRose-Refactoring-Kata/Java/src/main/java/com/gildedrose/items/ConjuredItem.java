package com.gildedrose.items;


public class ConjuredItem implements ItemPersonalized {

    private final Item item;

    public ConjuredItem(Item item) {
        this.item = item;
    }

    public void update() {
        item.sellIn -= 1;
        if (item.sellIn > 0) {
            decrementQualityBy(2);
        } else {
            decrementQualityBy(4);
        }
    }

    private void decrementQualityBy(int quality) {
        item.quality -= quality;
    }
}
