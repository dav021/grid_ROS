package com.gildedrose.items;

public class AgedBrieItem implements ItemPersonalized {

    private final Item item;

    public AgedBrieItem(Item item) {
        this.item = item;
    }

    public void update() {
        item.sellIn -= 1;
        item.quality += 1;
    }
}
