defmodule Item do
  defstruct name: nil, sell_in: nil, quality: nil
end
